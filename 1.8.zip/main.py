a = int(input())
b = int(input())
l = int(input())
N = int(input())

print(a * N + a * (N-1) + b * 2 * (N-1) + l * 2)
